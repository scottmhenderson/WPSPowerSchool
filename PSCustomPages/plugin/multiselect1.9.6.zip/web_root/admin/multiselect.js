//version 1.9.6  7/5/2016
'use strict';

var MultiSelect = {
	ajaxResultArray : [],
	URLList : [],
	inAct : "",
	caseInsens : "",
	powerScheduler : "",
	
	displayLink: function () {
		MultiSelect.powerScheduler = (window.location.href.indexOf("PowerSchedule") > 0 ? "PS" : "Home");
		if(parseInt(MultiSelect.psVer) == "7") {
			$j("#navNewStudent2").parent().append('<a class="dialogDivM" title="Multi Select" href="#MultiSelectDialog">Multi Select</a>');
			$j("a.dialogDivM").css("visibility","visible");
			$j("h2:contains('Copy and Paste')").after('<p style="font-size: 8pt">Note: In PowerSchool 7.x selection is limited to 30 students at a time.</p>');
		}
		if(parseInt(MultiSelect.psVer) >= "8") {
			if(MultiSelect.powerScheduler == "Home") {
				$j("#storedSelections").after('<a class="dialogDivM" title="Multi Select" href="#MultiSelectDialog">Multi Select</a>');
			} else {
				$j("#ssAutoComplete").append('<a class="dialogDivM" title="Multi Select" href="#MultiSelectDialog">Multi Select</a>');
			}
		}
		$j("#multiSelVals").on("change", function(){
			$j("#rowCount").text($j(this).val().split(/\r|\r\n|\n/).length);
		});
	},
	
	formatData: function (fldName, idList) {
		switch (fldName) {
			case "studentnumber": 
				//idList = idList.replace(/\n+|\t+|\,+|\s+/g,",").replace(/^\,*|\,*$/g,"");
				//idList = idList.replace(/[^0-9a-zA-Z]/g,",").replace(/^\,*|\,{2}|\,*$/g,"");				
				//var idArray = $j.unique($j.map(idList.split(","), $j.trim));
				var idArray = idList.replace(/[^0-9a-zA-Z]/g,",").match(/\d+/g);
				idArray = $j.unique(idArray);
				if(idArray.length > 0) return idArray.join(",");
				break;
			case "statenumber": 
				var idArray = idList.replace(/[^0-9a-zA-Z]/g,",").match(/\w+/g);
				idArray = $j.unique(idArray);
				if(idArray.length > 0) return idArray.join(",");
				break;
			case "lastfirst":
				idList = idList.replace(/\'/g, "''");
				idList = idList.replace(/\n+/g,"@~").replace(/(\,\s)|\s{1}|\t+|\,/g, "@");
				var idArray = $j.unique($j.map(idList.split("~"), $j.trim));  //cf
				if(idArray.length > 0) return idArray.join(",").replace(/^\,*|\,*$/g,"");
				break;
			case "firstlast":
				idList = idList.replace(/\'/g, "''");
				idList = idList.replace(/\n+/g, "~").replace(/^~*|~*$/g,"");
				var idArray = $j.unique($j.map(idList.split("~"), $j.trim));  //cf
				return $j.map(idArray, function(val,i){var varlist = val.split(/\t|\,|\s/g); return varlist[1]+"@"+varlist[0]+"@";}).join(",");
				break;
		}
	},

	getIDsFromPS: function (dataType) {
		var idsToRequest = MultiSelect.URLList.shift();
		if (idsToRequest != undefined) {
			$j.ajax({ 
				type: "POST",
				url: "/admin/multiselect.json",
				dataType: "html",
				data: "dt=" + dataType + "&ia=" + MultiSelect.inAct + "&cs=" + MultiSelect.caseInsens + "&data=" + idsToRequest + "&ps=" + MultiSelect.powerScheduler,
				cache: false,
				async: false
			}).done(function(html) {
				if (html.indexOf(",") != -1) {
					MultiSelect.ajaxResultArray.push(html);
				}
			}).always(window.setTimeout(MultiSelect.getIDsFromPS(dataType), 1000));
		} else {
			window.setTimeout(MultiSelect.makeSelection(), 1000);
		};
	},

	collectIDs: function () {
		MultiSelect.ajaxResultArray = [];
		MultiSelect.URLList = [];
		MultiSelect.inAct = ($j("#incInactStud:checked").length == 1 ? "X" : "");
		MultiSelect.caseInsens = ($j("#caseInsens:checked").length == 1 ? "X" : "");
		var idList = $j("#multiSelVals").val() + "\n";
		var fldName = $j("#fldName option:selected").val();
		var formattedData = MultiSelect.formatData(fldName, idList);
		var nLen = 10;
		var joinChar = "~";
		switch (fldName) {
			case "statenumber": 
				nLen = 100;
				joinChar = ",";
				break;
			case "studentnumber": 
				nLen = 500;
				joinChar = ",";
				break;
			default:
				nLen = 10;
				joinChar = "~";
				break;
		}
		var idArray = formattedData.split(",");
		var len = idArray.length;
		for (var i = 0; i < len; i += nLen) {
			MultiSelect.URLList.push(idArray.slice(i, i + nLen).join(joinChar));
		}
		$j(".ui-dialog-titlebar-close").trigger("click");
		MultiSelect.getIDsFromPS(fldName);
	},

	makeSelection: function () {
		var idList = MultiSelect.ajaxResultArray.join('').replace(/\r\n|\s/g,'');
		$j.ajax({ 
			type: "POST",
			url: "/admin/studentlist/functions.html",
			dataType: "html",
			data: "ac=buildsel;table=students;list=" + idList,
			cache: false,
			async: false
		}).done(function(html) {
			window.closeLoading();
			if(MultiSelect.powerScheduler == "Home") {
				window.setTimeout(window.location.assign("/admin/home.html"), 2000);
			} else {
				window.setTimeout(parent.location.reload(), 2000);
			}
		})
	}

}
