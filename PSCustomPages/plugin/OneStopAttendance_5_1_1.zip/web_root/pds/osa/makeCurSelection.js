function selectStudents(action, collectClass) {
  if(typeof loadingDialog == "function"){loadingDialog();}
	if(!collectClass) collectClass = 'studentIDs';
  if(!action) action = 'replace';
	var curSelect = jQuery.unique(jQuery('.'+collectClass).map(function() {return "ids=" + jQuery(this).val();})).get().join('&');
	curSelect = curSelect + '&selectionAction='+ action +'&temp=false';
	jQuery.ajax({
		type: "POST",
		url:  "/admin/SaveSelectedStudentsToSelection.action",
		cache: false,
		data: curSelect.replace(/ids=&/gi,''),
		success: function(){
			//window.open("/admin/studentlist/functions.html","_new");
			OpenInNewTab("/admin/studentlist/functions.html")
			closeLoading();
		},
		error: function(){
			if(typeof closeLoading == "function"){closeLoading();}
			jQuery('body').append('<div id="curSelectFail" title="Error"><p>There was a error making the students the current selection.</p></div>');
			jQuery("#curSelectFail").dialog();
		}
	}); 
};
function OpenInNewTab(url) {
  var win=window.open(url, '_blank');
  win.focus();
}